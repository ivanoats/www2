=== SustainableWebsites WordPress Subcategories Widget ===
Contributors: ivanoats
Plugin homepage: http://www.sustainablewebsites.com/wordpress-subcategories-widget
Tags: categories, widgets
Requires at least: 3.0
Tested up to: 3.0.5
Stable tag: 0.2

This WordPress Subcategories Widget displays all subcategories on a WordPress category archive page. 

== Description ==

This WordPress Subcategories Widget displays all subcategories on a WordPress category archive page.

The widget will not show un-necessarily on pages or posts.

It's a simple widget that does exactly what it says! If you have any suggestions please let me know at http://www.sustainablewebsites.com/contact

== Installation ==

1. Extract the zipfile
2. Upload the folder to /wp-content/plugins
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Drag the widget to a sidebar in the Appearance | Widgets menu

== Frequently Asked Questions ==

None yet, let me know!

== Changelog ==

= 0.2 =
* First public release